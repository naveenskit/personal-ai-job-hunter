# PROJECT_MEMORY.md
# Personal AI Job Hunter — Source of Truth

**Version:** 0.1.0 | **Current Phase:** 0 Complete → Ready for Phase 1  
**Last Updated:** Phase 0

---

## ✅ Completed Phases

### Phase 0 — Planning (COMPLETE)
All planning documents generated in `docs/`:
- `PRD.md` — Requirements, scoring model, state machine, constraints
- `ARCHITECTURE_SUMMARY.md` — Layered architecture, agent graph, data flow, AI abstraction
- `DATABASE_SUMMARY.md` — Full schema (9 tables), repository pattern, migration path
- `API_DESIGN.md` — REST endpoints, Telegram commands, service contracts (Protocol signatures)
- `FOLDER_STRUCTURE.md` — Complete file tree
- `ROADMAP.md` — 15-phase plan with deliverables per phase
- `PROJECT_MEMORY.md` — This file

---

## ⏳ Pending Phases

| Phase | Name | Status |
|-------|------|--------|
| 1 | Core Foundation | NEXT |
| 2 | Resume Intelligence | Pending |
| 3 | Job Discovery Engine | Pending |
| 4 | Company Research Agent | Pending |
| 5 | Matching & Scoring Engine | Pending |
| 6 | Email Generator | Pending |
| 7 | LinkedIn Generator | Pending |
| 8 | Application Tracker | Pending |
| 9 | Learning Engine | Pending |
| 10 | Skill Gap Engine | Pending |
| 11 | Telegram Bot | Pending |
| 12 | Reporting System | Pending |
| 13 | Dashboard UI | Pending |
| 14 | Testing | Pending |
| 15 | Deployment | Pending |

---

## Architecture Decisions

| ID | Decision | Rationale |
|----|----------|-----------|
| AD-01 | SQLAlchemy 2.0 async + aiosqlite | PostgreSQL-ready, zero code change to migrate |
| AD-02 | Pydantic v2 for all models | Type safety, fast validation, JSON serialization |
| AD-03 | structlog for logging | JSON-structured, machine-parseable, per-module |
| AD-04 | AIProvider Protocol abstraction | Swap Gemini → OpenAI → Claude without changing agents |
| AD-05 | JobSource Protocol abstraction | Add new sources without modifying discovery agent |
| AD-06 | Repository Pattern for all DB ops | Testable, no raw SQL in business logic |
| AD-07 | httpx for HTTP (async) | Native async, better than aiohttp ergonomics |
| AD-08 | PyMuPDF (fitz) for PDF parsing | Best text extraction quality |
| AD-09 | APScheduler 3.x | Lightweight, in-process, proven |
| AD-10 | Flask + Flask-RESTX for API/UI | Simple, hackable, no async overhead for UI |
| AD-11 | Gemini API (primary), OpenAI/Claude (future) | As specified; provider abstraction handles this |
| AD-12 | Content hash for dedup | SHA256(title + company + location) = fast exact dedup |

---

## Database Schema (Current)

Tables (9): `resumes`, `companies`, `opportunities`, `opportunity_scores`, `applications`, `application_events`, `outreach_messages`, `skill_gaps`, `weekly_reports`, `telegram_subscriptions`

Full DDL in `docs/DATABASE_SUMMARY.md`

---

## API Contracts (Key)

### AIProvider Protocol
```python
async def complete(prompt: str, system: str, temperature: float, max_tokens: int) -> str
async def embed(text: str) -> list[float]
```

### JobSource Protocol
```python
async def fetch(query: JobQuery, limit: int) -> list[RawOpportunity]
async def health_check() -> bool
```

### BaseAgent Protocol
```python
async def run() -> AgentResult
async def health_check() -> bool
```

---

## Scoring Formula
```
Score = resume_match(0.35) + hiring_probability(0.20) + 
        location_preference(0.15) + freshness(0.15) + 
        company_quality(0.10) + competition_estimate(0.05)
```
Bands: 95-100 Dream | 90-94 Excellent | 80-89 Strong | 70-79 Good | <70 Low

---

## Application State Machine
```
DISCOVERED → RESEARCHED → MATCHED → OUTREACH_SENT → APPLIED 
→ ACKNOWLEDGED → INTERVIEWING → OFFERED / REJECTED / GHOSTED / WITHDRAWN
```

---

## Key Environment Variables Needed (Phase 1)

```env
# AI
GEMINI_API_KEY=

# Telegram
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=

# Database
DATABASE_URL=sqlite+aiosqlite:///./data/jobhunter.db

# App
APP_SECRET_KEY=
API_SECRET_KEY=
LOG_LEVEL=INFO
ENVIRONMENT=development
```

---

## Known Issues

None at Phase 0.

---

## Next: Phase 1 Instructions

Generate these files in order:

1. `requirements.txt` — pinned production deps
2. `requirements-dev.txt` — dev/test deps
3. `pyproject.toml` — project metadata + tool config
4. `.env.example` — all env vars with descriptions
5. `.gitignore`
6. `config/settings.py` — Pydantic BaseSettings
7. `config/location_preferences.yaml`
8. `config/role_preferences.yaml`
9. `config/job_sources.yaml`
10. `config/scoring_weights.yaml`
11. `app/core/logging.py`
12. `app/core/exceptions.py`
13. `app/core/types.py`
14. `app/core/rate_limiter.py`
15. `app/core/retry.py`
16. `app/database/models.py` — all SQLAlchemy models
17. `app/database/connection.py`
18. `app/database/base_repository.py`
19. All 8 repositories in `app/database/repositories/`
20. `app/ai/provider.py` — Protocol + factory
21. `app/ai/gemini_provider.py`
22. `main.py`
23. Updated `PROJECT_MEMORY.md`

Do NOT regenerate Phase 0 docs. Output new files only.
